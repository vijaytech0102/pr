package com.airport.capstone.controller;
 
import com.airport.capstone.entity.User;
import com.airport.capstone.entity.enums.ApprovalStatus;
import com.airport.capstone.entity.enums.Role;
import com.airport.capstone.repository.UserRepository;
import org.springframework.web.bind.annotation.*;
 
import java.util.List;
 
@RestController
@RequestMapping("/admin")
public class AdminController {
 
    private final UserRepository userRepository;
 
    public AdminController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }
 
    @GetMapping("/managers/{status}")
    public List<User> getManagersByApprovalStatus(@PathVariable ApprovalStatus status) {
        return userRepository.findByRoleAndApprovalStatus(Role.MANAGER, status);
    }
 
    @PutMapping("/approve/{managerId}")
    public String approveManager(@PathVariable Long managerId) {
        User manager = userRepository.findById(managerId).orElseThrow(() -> new RuntimeException("Manager not found"));
        manager.setApprovalStatus(ApprovalStatus.APPROVED);
        userRepository.save(manager);
        return "Manager approved!";
    }
 
    @PutMapping("/reject/{managerId}")
    public String rejectManager(@PathVariable Long managerId) {
        User manager = userRepository.findById(managerId).orElseThrow(() -> new RuntimeException("Manager not found"));
        manager.setApprovalStatus(ApprovalStatus.REJECTED);
        userRepository.save(manager);
        return "Manager rejected!";
    }
}