package com.airport.capstone.controller;


import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.airport.capstone.entity.enums.ApprovalStatus;
import com.airport.capstone.entity.enums.Role;
import com.airport.capstone.payload.RegistrationRequest;
import com.airport.capstone.payload.RegistrationResponse;
import com.airport.capstone.payload.UserDto;
import com.airport.capstone.service.UserService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;


@Tag(name = "2. User Controller")
@RestController
@RequestMapping("/api/user")
public class UserController {

    @Autowired
    private  UserService userService;

    @Operation(summary = "Registration a new user", description = "This endpoint allows users to sign up with a specified role")
    @PostMapping("/signUp")
    public ResponseEntity<RegistrationResponse> signUp(@Validated @RequestBody RegistrationRequest registrationRequest, @RequestParam("role") Set<Role> role) {
        RegistrationResponse response = userService.signUp(registrationRequest, role);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }
    
    @Operation(summary = "Show the current user details")
    @GetMapping("/profile")
    public ResponseEntity<UserDto> profileDetails() {
        UserDto user = userService.getProfileDetails();
        return ResponseEntity.ok(user);
    }


    @PutMapping("/admin/approve-manager/{managerId}")
    public ResponseEntity<UserDto> approveManager(@PathVariable Long managerId, @RequestParam ApprovalStatus approve) {
        return ResponseEntity.ok(userService.approveManager(managerId, approve));
    }

    @GetMapping("/admin/managers")
    public ResponseEntity<List<UserDto>> getManagers(@RequestParam(required = false) ApprovalStatus approved) {
        List<UserDto> managers = userService.getManagersByApprovalStatus(approved);
        return ResponseEntity.ok(managers);
    }
}
