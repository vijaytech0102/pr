package com.airport.capstone.entity.enums;

public enum ApprovalStatus {
    PENDING,
    APPROVED,
    REJECTED
}
