package com.airport.capstone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CapstoneDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CapstoneDemoApplication.class, args);
	}

}
