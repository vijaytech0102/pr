package com.airport.capstone.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.airport.capstone.entity.User;
import com.airport.capstone.entity.enums.ApprovalStatus;
import com.airport.capstone.entity.enums.Role;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByEmailOrMobileNumber(String email, String mobileNumber);

    Optional<User> findByEmail(String email);

    Optional<User> findByMobileNumber(String mobileNumber);

    List<User> findByRole(Role role);
    List<User> findByRoleAndApproved(Role role, ApprovalStatus APPROVED );
    List<User> findByRoleAndApprovalStatus(Role role, ApprovalStatus approvalStatus); // Updated method
    
}
