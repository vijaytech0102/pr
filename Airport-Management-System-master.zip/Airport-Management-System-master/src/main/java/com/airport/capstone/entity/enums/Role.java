package com.airport.capstone.entity.enums;

public enum Role {

    ADMIN, MANAGER
}
