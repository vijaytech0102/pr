package com.airport.entity;
import com.airport.entity.enumeration.Role;
import com.airport.entity.enumeration.Status;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class PlaneTest {

    private Plane plane;
    private User user;

    @BeforeEach
    public void setUp() {
        user = new User();
        user.setId(1L);
        user.setFirstName("John");
        user.setLastName("Doe");
        user.setAge(30);
        user.setGender("male");
        user.setContactNumber("1234567890");
        user.setEmailId("john.doe@example.com");
        user.setVendorId("vendor123");
        user.setPassword("password");
        user.setRole(Role.ROLE_ADMIN);
        user.setStatus(Status.APPROVED);

        plane = new Plane();
        plane.setId(1L);
        plane.setPlaneName("Boeing 747");
        plane.setModel("747-400");
        plane.setCapacity(416);
        plane.setStatus("INACTIVE");
        plane.setUser(user);
    }

    @Test
    public void testUserRoleAdmin() {
        user.setRole(Role.valueOf("ROLE_ADMIN"));
        Assertions.assertEquals(Role.ROLE_ADMIN.name(), user.getRole().name());
    }

    @Test
    public void testUserRoleManager() {
        user.setRole(Role.valueOf("ROLE_MANAGER"));
        Assertions.assertEquals(Role.ROLE_MANAGER.name(), user.getRole().name());
    }

    @Test
    public void testPlaneEntity() {
        assertEquals(1L, plane.getId());
        assertEquals("Boeing 747", plane.getPlaneName());
        assertEquals("747-400", plane.getModel());
        assertEquals(416, plane.getCapacity());
        assertEquals("INACTIVE", plane.getStatus());
        assertEquals(user, plane.getUser());
    }

    @Test
    public void testPlaneNameValidation() {
        plane.setPlaneName("A");
        assertFalse(plane.getPlaneName().length() >= 2 && plane.getPlaneName().length() <= 30);
    }

    @Test
    public void testModelValidation() {
        plane.setModel("A");
        assertFalse(plane.getModel().length() >= 2 && plane.getModel().length() <= 30);
    }

    @Test
    public void testCapacityValidation() {
        plane.setCapacity(0);
        assertTrue(plane.getCapacity() < 1);
    }

    @Test
    public void testStatusNotNull() {
        plane.setStatus(null);
        assertNull(plane.getStatus());
    }

    @Test
    public void testUserAssociation() {
        assertNotNull(plane.getUser());
        assertEquals(user, plane.getUser());
    }
}
