package com.airport.controller;

import com.airport.configuration.JWTFilter;
import com.airport.entity.Plane;
import com.airport.payload.PlaneDto;
import com.airport.repository.PlaneRepository;
import com.airport.repository.UserRepository;
import com.airport.service.JWTService;
import com.airport.service.impl.PlaneServiceImpl;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(PlaneController.class)
@AutoConfigureMockMvc(addFilters = false)
public class PlaneControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private PlaneServiceImpl planeServiceImpl;

    @MockBean
    private JWTFilter jwtFilter;

    @MockBean
    private JWTService jwtService;



    @MockBean
    private PlaneRepository planeRepository;

    @MockBean
    private UserRepository userRepository;

    @Autowired
    private ObjectMapper objectMapper;

    private PlaneDto planeDto;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        planeDto = new PlaneDto();
        planeDto.setPlaneName("lufthansa");
        planeDto.setModel("l413");
        planeDto.setCapacity(416);
        planeDto.setStatus("INACTIVE");
    }

    @Test
    public void testAddPlane_Success() throws Exception {
        when(planeRepository.findByPlaneName(anyString())).thenReturn(Optional.empty());
        when(planeServiceImpl.createAddPlane(any(PlaneDto.class))).thenReturn(planeDto);

        mockMvc.perform(post("/api/v1/plane/admin/add-plane")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(planeDto)))
                .andExpect(status().isCreated())
                .andExpect(content().string("plane details added successfully!!!!"));
    }

    @Test
    public void testAddPlane_PlaneNameTaken() throws Exception {
        when(planeRepository.findByPlaneName(anyString())).thenReturn(Optional.of(new Plane()));

        mockMvc.perform(post("/api/v1/plane/admin/add-plane")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(planeDto)))
                .andExpect(status().isBadRequest())
                .andExpect(content().string("PlaneName already taken"));
    }

    @Test
    public void testGetAllPlanesInfo() throws Exception {
        List<PlaneDto> planeDtos = Collections.singletonList(planeDto);
        when(planeServiceImpl.findAllPlanesDetails()).thenReturn(planeDtos);

        mockMvc.perform(get("/api/v1/plane/admin-viewPlanes"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].planeName").value("lufthansa"));
    }

    @Test
    public void testViewPlaneInfoById() throws Exception {
        when(planeServiceImpl.findPlaneDetailsById(anyLong())).thenReturn(planeDto);

        mockMvc.perform(get("/api/v1/plane/view-plane-byId/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.planeName").value("lufthansa"));
    }

    @Test
    public void testUpdatePlaneInfo() throws Exception {
        Plane planeDetails = new Plane();
        when(planeServiceImpl.updatePlane(anyString(), any(Plane.class))).thenReturn(planeDetails);

        mockMvc.perform(put("/api/v1/plane/admin-update-planeInfo")
                        .param("planeName", "lufthansa")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(planeDetails)))
                .andExpect(status().isOk())
                .andExpect(content().string("Plane details are updated successfully!!!"));
    }

    @Test
    public void testDeletePlane() throws Exception {
        doNothing().when(planeServiceImpl).deletePlane(anyString());

        mockMvc.perform(delete("/api/v1/plane")
                        .param("planeName", "lufthansa"))
                .andExpect(status().isOk())
                .andExpect(content().string("Plane details are Deleted successfully!!!"));
    }
}
