package com.airport.service;

import com.airport.entity.Hanger;
import com.airport.entity.User;
import com.airport.exception.ResourceNotFoundException;
import com.airport.payload.HangerDto;
import com.airport.repository.HangerRepository;
import com.airport.repository.UserRepository;
import com.airport.service.impl.HangerServiceImpl;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

public class HangerServiceImplTest {

    @Mock
    private HangerRepository hangerRepository;

    @Mock
    private UserRepository userRepository;

    @Mock
    private ObjectMapper objectMapper;

    @InjectMocks
    private HangerServiceImpl hangerServiceImpl;

    private Hanger hanger;
    private HangerDto hangerDto;
    private User user;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        hanger = new Hanger();
        hanger.setId(1L);
        hanger.setHangerName("Alpha");
        hanger.setLocation("Left Wing");
        hanger.setCapacity(10);
        hanger.setStatus("Available");

        hangerDto = new HangerDto();
        hangerDto.setHangerName("Alpha");
        hangerDto.setLocation("Left Wing");
        hangerDto.setCapacity(10);
        hangerDto.setStatus("Available");

        user = new User();
        user.setId(1L);
        user.setEmailId("admin@example.com");
    }

    @Test
    public void testAddHanger() {
        when(hangerRepository.save(any(Hanger.class))).thenReturn(hanger);
        when(objectMapper.convertValue(any(Hanger.class), eq(HangerDto.class))).thenReturn(hangerDto);
        HangerDto dto = hangerServiceImpl.addHanger(hanger);
        assertNotNull(dto);
        assertEquals(hanger.getHangerName(), dto.getHangerName());
    }

    @Test
    public void testUpdateHanger() {
        when(hangerRepository.findByHangerName(anyString())).thenReturn(Optional.of(hanger));
        when(userRepository.findByEmailId(anyString())).thenReturn(Optional.of(user));
        hangerServiceImpl.updateHanger("Alpha", hanger, "admin@example.com");
        verify(hangerRepository, times(1)).save(hanger);
    }

    @Test
    public void testGetHangerById() {
        when(hangerRepository.findById(anyLong())).thenReturn(Optional.of(hanger));
        when(objectMapper.convertValue(any(Hanger.class), eq(HangerDto.class))).thenReturn(hangerDto);
        HangerDto result = hangerServiceImpl.getHangerById(1L);
        assertNotNull(result);
        assertEquals(hangerDto.getHangerName(), result.getHangerName());
    }

    @Test
    public void testGetAllHangers() {
        when(hangerRepository.findAll()).thenReturn(Collections.singletonList(hanger));
        when(objectMapper.convertValue(any(Hanger.class), eq(HangerDto.class))).thenReturn(hangerDto);
        List<HangerDto> result = hangerServiceImpl.getAllHangers();
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals(hangerDto.getHangerName(), result.get(0).getHangerName());
    }

    @Test
    public void testDeleteHanger() {
        doNothing().when(hangerRepository).deleteById(anyLong());
        hangerServiceImpl.deleteHanger(1L);
        verify(hangerRepository, times(1)).deleteById(1L);
    }

    @Test
    public void testGetHangerById_NotFound() {
        when(hangerRepository.findById(anyLong())).thenReturn(Optional.empty());
        assertThrows(ResourceNotFoundException.class, () -> hangerServiceImpl.getHangerById(1L));
    }
}
