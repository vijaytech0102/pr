package com.airport.controller;


import com.airport.configuration.JWTFilter;
import com.airport.entity.User;
import com.airport.entity.enumeration.Role;
import com.airport.entity.enumeration.Status;
import com.airport.payload.LoginDto;
import com.airport.payload.TokenDto;
import com.airport.payload.UserDto;
import com.airport.service.JWTService;
import com.airport.service.UserService;
import com.airport.repository.UserRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Optional;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(UserController.class)
@AutoConfigureMockMvc(addFilters = false)
public class UserControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private UserService userService;

    @MockBean
    private UserRepository userRepository;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private JWTFilter jwtFilter;

    @MockBean
    private JWTService jwtService;

    private UserDto userDto;
    private LoginDto loginDto;
    private TokenDto tokenDto;

    @BeforeEach
    public void setUp() {
        userDto = new UserDto();
        userDto.setFirstName("John");
        userDto.setLastName("Doe");
        userDto.setAge(30);
        userDto.setGender("male");
        userDto.setContactNumber("1234567890");
        userDto.setEmailId("john.doe@example.com");
        userDto.setVendorId("vendor123");
        userDto.setPassword("password");
        userDto.setRole(Role.ROLE_ADMIN);
        userDto.setStatus(Status.APPROVED);

        loginDto = new LoginDto();
        loginDto.setEmailId("john.doe@example.com");
        loginDto.setPassword("password");

        tokenDto = new TokenDto();
        tokenDto.setToken("sampleToken");
        tokenDto.setType("JWT");
    }

    @Test
    public void testRegisterAdmin() throws Exception {
        when(userRepository.findByEmailId(anyString())).thenReturn(Optional.empty());
        when(userRepository.findByContactNumber(anyString())).thenReturn(Optional.empty());
        when(userService.createUser(any(UserDto.class))).thenReturn(userDto);

        mockMvc.perform(post("/api/v1/user/register-admin")
                        .param("role", "ROLE_ADMIN")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(userDto)))
                .andExpect(status().isCreated())
                .andExpect(content().string("Your Details are submitted successfully"));
    }

    @Test
    public void testRegisterManager() throws Exception {
        when(userRepository.findByEmailId(anyString())).thenReturn(Optional.empty());
        when(userRepository.findByContactNumber(anyString())).thenReturn(Optional.empty());
        when(userService.createUser(any(UserDto.class))).thenReturn(userDto);

        mockMvc.perform(post("/api/v1/user/register-manager")
                        .param("role", "ROLE_MANAGER")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(userDto)))
                .andExpect(status().isCreated())
                .andExpect(content().string("Your Details are submitted successfully. Awaiting approval from admin"));
    }

    @Test
    public void testLoginAdmin() throws Exception {
        when(userService.verifyLogin(any(LoginDto.class))).thenReturn("sampleToken");

        mockMvc.perform(post("/api/v1/user/login-admin")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(loginDto)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.token").value("sampleToken"))
                .andExpect(jsonPath("$.type").value("JWT"));
    }

    @Test
    public void testLoginManager() throws Exception {
        when(userService.verifyLogin(any(LoginDto.class))).thenReturn("sampleToken");

        mockMvc.perform(post("/api/v1/user/login-manager")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(loginDto)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.token").value("sampleToken"))
                .andExpect(jsonPath("$.type").value("JWT"));
    }

    @Test
    public void testGetAllUsers() throws Exception {
        when(userService.getAllUsers()).thenReturn(List.of(userDto));

        mockMvc.perform(get("/api/v1/user"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].firstName").value("John"))
                .andExpect(jsonPath("$[0].lastName").value("Doe"));
    }

    @Test
    public void testApproveManager() throws Exception {
        User user = new User();
        user.setEmailId("john.doe@example.com");
        when(userService.getUserByEmailId(anyString())).thenReturn(user);
        when(userService.approveManagerUser(anyString())).thenReturn(userDto);

        mockMvc.perform(put("/api/v1/user/admin-approve/john.doe@example.com"))
                .andExpect(status().isOk())
                .andExpect(content().string("Manager approved successfully!!! \n manager details are as follows " + user));
    }

    @Test
    public void testRejectManager() throws Exception {
        User user = new User();
        user.setEmailId("john.doe@example.com");
        when(userService.getUserByEmailId(anyString())).thenReturn(user);

        mockMvc.perform(put("/api/v1/user/admin-reject/john.doe@example.com"))
                .andExpect(status().isOk())
                .andExpect(content().string("Manager is rejected"));
    }
}
