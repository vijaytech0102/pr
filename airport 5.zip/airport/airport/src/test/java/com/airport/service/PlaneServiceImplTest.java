package com.airport.service;

import com.airport.entity.Plane;
import com.airport.exception.ResourceNotFoundException;
import com.airport.payload.PlaneDto;
import com.airport.repository.PlaneRepository;
import com.airport.repository.UserRepository;
import com.airport.service.impl.PlaneServiceImpl;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

public class PlaneServiceImplTest {

    @Mock
    private PlaneRepository planeRepository;

    @Mock
    private UserRepository userRepository;

    @Mock
    private ObjectMapper objectMapper;

    @InjectMocks
    private PlaneServiceImpl planeServiceImpl;

    private Plane plane;
    private PlaneDto planeDto;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);

        plane = new Plane();
        plane.setId(1L);
        plane.setPlaneName("Boeing 747");
        plane.setModel("747-400");
        plane.setCapacity(416);
        plane.setStatus("INACTIVE");

        planeDto = new PlaneDto();
        planeDto.setPlaneName("Boeing 747");
        planeDto.setModel("747-400");
        planeDto.setCapacity(416);
        planeDto.setStatus("INACTIVE");
    }

    @Test
    public void testCreateAddPlane() {
        when(objectMapper.convertValue(any(PlaneDto.class), eq(Plane.class))).thenReturn(plane);
        when(planeRepository.save(any(Plane.class))).thenReturn(plane);

        planeServiceImpl.createAddPlane(planeDto);

        verify(planeRepository, times(1)).save(any(Plane.class));
    }

    @Test
    public void testFindAllPlanesDetails() {
        when(planeRepository.findAll()).thenReturn(Collections.singletonList(plane));
        when(objectMapper.convertValue(any(Plane.class), eq(PlaneDto.class))).thenReturn(planeDto);

        List<PlaneDto> planeDtos = planeServiceImpl.findAllPlanesDetails();

        assertNotNull(planeDtos);
        assertEquals(1, planeDtos.size());
        assertEquals("Boeing 747", planeDtos.get(0).getPlaneName());
    }

    @Test
    public void testFindPlaneDetailsById() {
        when(planeRepository.findById(anyLong())).thenReturn(Optional.of(plane));
        when(objectMapper.convertValue(any(Plane.class), eq(PlaneDto.class))).thenReturn(planeDto);

        PlaneDto foundPlaneDto = planeServiceImpl.findPlaneDetailsById(1L);

        assertNotNull(foundPlaneDto);
        assertEquals("Boeing 747", foundPlaneDto.getPlaneName());
    }

    @Test
    public void testFindPlaneDetailsById_NotFound() {
        when(planeRepository.findById(anyLong())).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> {
            planeServiceImpl.findPlaneDetailsById(1L);
        });
    }

    @Test
    public void testUpdatePlane() {
        when(planeRepository.findByPlaneName(anyString())).thenReturn(Optional.of(plane));
        when(planeRepository.save(any(Plane.class))).thenReturn(plane);

        Plane updatedPlane = planeServiceImpl.updatePlane("Boeing 747", plane);

        assertNotNull(updatedPlane);
        assertEquals("Boeing 747", updatedPlane.getPlaneName());
    }

    @Test
    public void testDeletePlane() {
        when(planeRepository.findByPlaneName(anyString())).thenReturn(Optional.of(plane));
        doNothing().when(planeRepository).deleteById(anyLong());

        planeServiceImpl.deletePlane("Boeing 747");

        verify(planeRepository, times(1)).deleteById(anyLong());
    }
}
