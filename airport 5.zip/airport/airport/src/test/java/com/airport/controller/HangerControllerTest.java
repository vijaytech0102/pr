package com.airport.controller;

import com.airport.configuration.JWTFilter;
import com.airport.entity.Hanger;
import com.airport.entity.User;
import com.airport.payload.HangerDto;
import com.airport.repository.HangerRepository;
import com.airport.repository.UserRepository;
import com.airport.service.JWTService;
import com.airport.service.impl.HangerServiceImpl;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(HangerController.class)
@AutoConfigureMockMvc(addFilters = false)
public class HangerControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private HangerServiceImpl hangerServiceImpl;

    @MockBean
    private JWTFilter jwtFilter;

    @MockBean
    private JWTService jwtService;
    @MockBean
    private HangerRepository hangerRepository;

    @MockBean
    private UserRepository userRepository;

    @Autowired
    private ObjectMapper objectMapper;

    private HangerDto hangerDto;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        hangerDto = new HangerDto();
        hangerDto.setHangerName("Alpha");
        hangerDto.setLocation("Left Wing");
        hangerDto.setCapacity(10);
        hangerDto.setStatus("Available");
    }

    @Test
    public void testAddHanger_Success() throws Exception {
        when(hangerRepository.findByHangerName(anyString())).thenReturn(Optional.empty());
        when(userRepository.findByEmailId(anyString())).thenReturn(Optional.of(new User()));
        when(hangerServiceImpl.addHanger(any(Hanger.class))).thenReturn(new HangerDto());

        mockMvc.perform(post("/api/v1/hanger/addHanger")
                        .param("emailId", "admin@example.com")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(hangerDto)))
                .andExpect(status().isOk())
                .andExpect(content().string("Hangar added successfully."));
    }

    @Test
    public void testAddHanger_HangerNameTaken() throws Exception {
        when(hangerRepository.findByHangerName(anyString())).thenReturn(Optional.of(new Hanger()));

        mockMvc.perform(post("/api/v1/hanger/addHanger")
                        .param("emailId", "admin@example.com")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(hangerDto)))
                .andExpect(status().isBadRequest())
                .andExpect(content().string("Hanger Name already taken"));
    }

    @Test
    public void testGetAllHangersByAdmin() throws Exception {
        List<HangerDto> hangerDtos = Collections.singletonList(hangerDto);
        when(hangerServiceImpl.getAllHangers()).thenReturn(hangerDtos);

        mockMvc.perform(get("/api/v1/hanger/admin-view-hangers"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].hangerName").value("Alpha"));
    }

    @Test
    public void testGetHangerById() throws Exception {
        when(hangerServiceImpl.getHangerById(anyLong())).thenReturn(hangerDto);

        mockMvc.perform(get("/api/v1/hanger/admin-view-specificHanger/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.hangerName").value("Alpha"));
    }

    @Test
    public void testUpdateHanger() throws Exception {
        Hanger hangerDetails = new Hanger();
        when(hangerServiceImpl.updateHanger(anyString(), any(Hanger.class), anyString())).thenReturn(hangerDetails);

        mockMvc.perform(put("/api/v1/hanger/admin-update/Alpha")
                        .param("emailId", "admin@example.com")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(hangerDetails)))
                .andExpect(status().isOk())
                .andExpect(content().string("Hangar updated successfully."));
    }

    @Test
    public void testDeleteHanger() throws Exception {
        doNothing().when(hangerServiceImpl).deleteHanger(anyLong());

        mockMvc.perform(delete("/api/v1/hanger")
                        .param("id", "1"))
                .andExpect(status().isOk())
                .andExpect(content().string("deleted"));
    }
}