package com.airport.controller;

import com.airport.configuration.JWTFilter;
import com.airport.entity.Pilot;
import com.airport.exception.ResourceNotFoundException;
import com.airport.payload.PilotDto;
import com.airport.repository.PilotRepository;
import com.airport.repository.PlaneRepository;
import com.airport.repository.UserRepository;
import com.airport.service.JWTService;
import com.airport.service.PilotService;
import com.airport.service.impl.PilotServiceImpl;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(PilotController.class)
@AutoConfigureMockMvc(addFilters = false)
public class PilotControllerTest{
    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private PilotServiceImpl pilotServiceImpl;

    @MockBean
    private PilotRepository pilotRepository;

    @MockBean
    private JWTService jwtService;

    @MockBean
    private JWTFilter jwtFilter;

    @MockBean
    private PlaneRepository planeRepository;

    @MockBean
    private UserRepository userRepository;

    @Autowired
    private ObjectMapper objectMapper;

    private PilotDto pilotDto;

    @BeforeEach
    public void setUp() {

        pilotDto = new PilotDto();
        pilotDto.setFirstName("John");
        pilotDto.setLastName("Doe");
        pilotDto.setLicenseNumber("LN12345");
        pilotDto.setExperience(10);
        pilotDto.setContactNumber("1234567890");
    }

    @Test
    public void testAddPilot_Success() throws Exception {
        when(pilotRepository.findByContactNumber(anyString())).thenReturn(Optional.empty());
        when(pilotRepository.findByLicenseNumber(anyString())).thenReturn(Optional.empty());
        when(pilotServiceImpl.savePilotDetails(any(PilotDto.class))).thenReturn(pilotDto);

        mockMvc.perform(post("/api/v1/pilots/admin/add-pilot")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(pilotDto)))
                .andExpect(status().isCreated())
                .andExpect(content().string("Pilot details added successfully!!!"));
    }

    @Test
    public void testAddPilot_ContactNumberTaken() throws Exception {
        when(pilotRepository.findByContactNumber(anyString())).thenReturn(Optional.of(new Pilot()));

        mockMvc.perform(post("/api/v1/pilots/admin/add-pilot")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(pilotDto)))
                .andExpect(status().isBadRequest())
                .andExpect(content().string("contact number already taken"));
    }

    @Test
    public void testAddPilot_LicenseNumberTaken() throws Exception {
        when(pilotRepository.findByLicenseNumber(anyString())).thenReturn(Optional.of(new Pilot()));

        mockMvc.perform(post("/api/v1/pilots/admin/add-pilot")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(pilotDto)))
                .andExpect(status().isBadRequest())
                .andExpect(content().string("License Number already exists!!!"));
    }

    @Test
    public void testGetAllPilots() throws Exception {
        List<PilotDto> pilotDtos = Collections.singletonList(pilotDto);
        when(pilotServiceImpl.getAllPilots()).thenReturn(pilotDtos);

        mockMvc.perform(get("/api/v1/pilots/view"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].firstName").value("John"));
    }

    @Test
    public void testGetPilotById() throws Exception {
        Pilot pilot = new Pilot();
        pilot.setId(1L);
        pilot.setFirstName("John");
        pilot.setLastName("Doe");
        pilot.setLicenseNumber("LN12345");
        pilot.setExperience(10);
        pilot.setContactNumber("1234567890");

        when(pilotServiceImpl.getPilotById(anyLong())).thenReturn(pilot);

        mockMvc.perform(get("/api/v1/pilots/view/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.firstName").value("John"));
    }

    @Test
    public void testUpdatePilotDetails() throws Exception {
        Pilot pilot = new Pilot();
        when(pilotServiceImpl.updatePilot(anyString(), any(Pilot.class), anyString())).thenReturn(pilot);

        mockMvc.perform(put("/api/v1/pilots/update/LN12345/lufthansa")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(pilot)))
                .andExpect(status().isOk())
                .andExpect(content().string("Pilot details updated successfully!!!!"));
    }



    @Test
    public void testDeletePilot_NotFound() {
        when(pilotRepository.findByContactNumber(anyString())).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> pilotServiceImpl.deletePilot("1234567890"));
    }

}
