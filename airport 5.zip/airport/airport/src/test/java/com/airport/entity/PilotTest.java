package com.airport.entity;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class PilotTest {

    private Pilot pilot;
    private Plane plane;

    @BeforeEach
    public void setUp() {
        plane = new Plane();
        plane.setId(1L);
        plane.setPlaneName("Boeing 747");
        plane.setModel("747-400");
        plane.setCapacity(416);
        plane.setStatus("INACTIVE");

        pilot = new Pilot();
        pilot.setId(1L);
        pilot.setFirstName("John");
        pilot.setLastName("Doe");
        pilot.setLicenseNumber("LN12345");
        pilot.setExperience(10);
        pilot.setContactNumber("1234567890");
        pilot.setPlane(plane);
    }

    @Test
    public void testPilotEntity() {
        assertEquals(1L, pilot.getId());
        assertEquals("John", pilot.getFirstName());
        assertEquals("Doe", pilot.getLastName());
        assertEquals("LN12345", pilot.getLicenseNumber());
        assertEquals(10, pilot.getExperience());
        assertEquals("1234567890", pilot.getContactNumber());
        assertEquals(plane, pilot.getPlane());
    }

    @Test
    public void testFirstNameNotNull() {
        pilot.setFirstName(null);
        assertNull(pilot.getFirstName());
    }

    @Test
    public void testLastNameNotNull() {
        pilot.setLastName(null);
        assertNull(pilot.getLastName());
    }

    @Test
    public void testLicenseNumberNotNull() {
        pilot.setLicenseNumber(null);
        assertNull(pilot.getLicenseNumber());
    }

    @Test
    public void testExperienceNotNull() {
        pilot.setExperience(null);
        assertNull(pilot.getExperience());
    }

    @Test
    public void testContactNumberPattern() {
        pilot.setContactNumber("12345");
        assertFalse(pilot.getContactNumber().matches("^\\d{10}$"));
    }

    @Test
    public void testPlaneAssociation() {
        assertNotNull(pilot.getPlane());
        assertEquals(plane, pilot.getPlane());
    }
}
