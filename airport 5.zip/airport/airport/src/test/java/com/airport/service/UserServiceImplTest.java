package com.airport.service;

import com.airport.entity.User;
import com.airport.entity.enumeration.Role;
import com.airport.entity.enumeration.Status;
import com.airport.exception.ResourceNotFoundException;
import com.airport.payload.LoginDto;
import com.airport.payload.UserDto;
import com.airport.repository.UserRepository;
import com.airport.service.JWTService;
import com.airport.service.impl.UserServiceImpl;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.security.crypto.bcrypt.BCrypt;

import java.util.Optional;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

public class UserServiceImplTest {

    @Mock
    private UserRepository userRepository;

    @Mock
    private JWTService jwtService;

    @Mock
    private ObjectMapper objectMapper;

    @InjectMocks
    private UserServiceImpl userServiceImpl;

    private UserDto userDto;
    private LoginDto loginDto;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);

        userDto = new UserDto();
        userDto.setFirstName("John");
        userDto.setLastName("Doe");
        userDto.setAge(30);
        userDto.setGender("male");
        userDto.setContactNumber("1234567890");
        userDto.setEmailId("john.doe@example.com");
        userDto.setVendorId("vendor123");
        userDto.setPassword("password");

        loginDto = new LoginDto();
        loginDto.setEmailId("john.doe@example.com");
        loginDto.setPassword("password");
    }

    @Test
    public void testCreateUser() {
        User user = new User();
        user.setFirstName("John");
        user.setLastName("Doe");
        user.setAge(30);
        user.setGender("male");
        user.setContactNumber("1234567890");
        user.setEmailId("john.doe@example.com");
        user.setVendorId("vendor123");
        user.setPassword("password");

        when(objectMapper.convertValue(any(UserDto.class), eq(User.class))).thenReturn(user);
        when(userRepository.save(any(User.class))).thenReturn(user);
        when(objectMapper.convertValue(any(User.class), eq(UserDto.class))).thenReturn(userDto);

        UserDto savedUserDto = userServiceImpl.createUser(userDto);

        assertNotNull(savedUserDto);
        assertEquals("John", savedUserDto.getFirstName());
        assertEquals("Doe", savedUserDto.getLastName());
    }

    @Test
    public void testGetAllUsers() {
        User user = new User();
        user.setFirstName("John");
        user.setLastName("Doe");

        when(userRepository.findAll()).thenReturn(List.of(user));
        when(objectMapper.convertValue(any(User.class), eq(UserDto.class))).thenReturn(userDto);

        List<UserDto> userDtos = userServiceImpl.getAllUsers();

        assertNotNull(userDtos);
        assertEquals(1, userDtos.size());
        assertEquals("John", userDtos.get(0).getFirstName());
    }

    @Test
    public void testGetUserByEmailId() {
        User user = new User();
        user.setEmailId("john.doe@example.com");

        when(userRepository.findByEmailId(anyString())).thenReturn(Optional.of(user));

        User foundUser = userServiceImpl.getUserByEmailId("john.doe@example.com");

        assertNotNull(foundUser);
        assertEquals("john.doe@example.com", foundUser.getEmailId());
    }

    @Test
    public void testVerifyLogin() {
        User user = new User();
        user.setEmailId("john.doe@example.com");
        user.setPassword(BCrypt.hashpw("password", BCrypt.gensalt()));
        user.setStatus(Status.APPROVED);

        when(userRepository.findByEmailId(anyString())).thenReturn(Optional.of(user));
        when(jwtService.generateToken(anyString())).thenReturn("sampleToken");

        String token = userServiceImpl.verifyLogin(loginDto);

        assertEquals("sampleToken", token);
    }

    @Test
    public void testApproveManagerUser() {
        User user = new User();
        user.setEmailId("john.doe@example.com");
        user.setRole(Role.ROLE_MANAGER);
        user.setStatus(Status.UNAPPROVED);

        when(userRepository.findByEmailId(anyString())).thenReturn(Optional.of(user));
        when(userRepository.save(any(User.class))).thenReturn(user);
        when(objectMapper.convertValue(any(User.class), eq(UserDto.class))).thenAnswer(invocation -> {
            User source = invocation.getArgument(0);
            UserDto target = new UserDto();
            target.setFirstName(source.getFirstName());
            target.setLastName(source.getLastName());
            target.setAge(source.getAge());
            target.setGender(source.getGender());
            target.setContactNumber(source.getContactNumber());
            target.setEmailId(source.getEmailId());
            target.setVendorId(source.getVendorId());
            target.setPassword(source.getPassword());
            target.setRole(source.getRole());
            target.setStatus(source.getStatus());
            return target;
        });

        UserDto approvedUserDto = userServiceImpl.approveManagerUser("john.doe@example.com");

        assertNotNull(approvedUserDto);
        assertEquals(Status.APPROVED, approvedUserDto.getStatus());
    }


    @Test
    public void testRejectManagerUser() {
        User user = new User();
        user.setEmailId("john.doe@example.com");

        when(userRepository.findByEmailId(anyString())).thenReturn(Optional.of(user));

        userServiceImpl.rejectManagerUser("john.doe@example.com");

        verify(userRepository, times(1)).save(user);
        assertEquals(Status.UNAPPROVED, user.getStatus());
    }
}
