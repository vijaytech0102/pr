package com.airport.service;

import com.airport.entity.Pilot;
import com.airport.entity.Plane;
import com.airport.exception.PilotNotFoundException;
import com.airport.exception.ResourceNotFoundException;
import com.airport.payload.PilotDto;
import com.airport.repository.PilotRepository;
import com.airport.repository.PlaneRepository;
import com.airport.service.impl.PilotServiceImpl;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultMatcher;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.content;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

public class PilotServiceImplTest {

    @Autowired
    private MockMvc mockMvc;

    @Mock
    private PilotRepository pilotRepository;

    @Mock
    private PlaneRepository planeRepository;

    @Mock
    private ObjectMapper objectMapper;

    @InjectMocks
    private PilotServiceImpl pilotServiceImpl;

    private PilotDto pilotDto;
    private Pilot pilot;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);

        pilotDto = new PilotDto();
        pilotDto.setFirstName("John");
        pilotDto.setLastName("Doe");
        pilotDto.setLicenseNumber("LN12345");
        pilotDto.setExperience(10);
        pilotDto.setContactNumber("1234567890");

        pilot = new Pilot();
        pilot.setFirstName("John");
        pilot.setLastName("Doe");
        pilot.setLicenseNumber("LN12345");
        pilot.setExperience(10);
        pilot.setContactNumber("1234567890");
    }

    @Test
    public void testSavePilotDetails() {
        when(objectMapper.convertValue(any(PilotDto.class), eq(Pilot.class))).thenReturn(pilot);
        when(objectMapper.convertValue(any(Pilot.class), eq(PilotDto.class))).thenReturn(pilotDto);
        when(pilotRepository.save(any(Pilot.class))).thenReturn(pilot);

        PilotDto savedPilotDto = pilotServiceImpl.savePilotDetails(pilotDto);

        assertNotNull(savedPilotDto);
        assertEquals("John", savedPilotDto.getFirstName());
    }

    @Test
    public void testGetAllPilots() {
        when(pilotRepository.findAll()).thenReturn(Collections.singletonList(pilot));
        when(objectMapper.convertValue(any(Pilot.class), eq(PilotDto.class))).thenReturn(pilotDto);

        List<PilotDto> pilotDtos = pilotServiceImpl.getAllPilots();

        assertNotNull(pilotDtos);
        assertEquals(1, pilotDtos.size());
        assertEquals("John", pilotDtos.get(0).getFirstName());
    }

    @Test
    public void testGetPilotById() {
        when(pilotRepository.findById(anyLong())).thenReturn(Optional.of(pilot));

        Pilot foundPilot = pilotServiceImpl.getPilotById(1L);

        assertNotNull(foundPilot);
        assertEquals("John", foundPilot.getFirstName());
    }

    @Test
    public void testGetPilotById_NotFound() {
        when(pilotRepository.findById(anyLong())).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> pilotServiceImpl.getPilotById(1L));
    }

    @Test
    public void testUpdatePilot() {
        Plane plane = new Plane();
        plane.setPlaneName("lufthansa");

        when(pilotRepository.findByLicenseNumber(anyString())).thenReturn(Optional.of(pilot));
        when(planeRepository.findByPlaneName(anyString())).thenReturn(Optional.of(plane));
        when(pilotRepository.save(any(Pilot.class))).thenReturn(pilot);

        Pilot updatedPilot = pilotServiceImpl.updatePilot("LN12345", pilot, "lufthansa");

        assertNotNull(updatedPilot);
        assertEquals("John", updatedPilot.getFirstName());
    }

}
