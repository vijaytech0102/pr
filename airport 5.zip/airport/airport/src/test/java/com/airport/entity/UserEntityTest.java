package com.airport.entity;

import com.airport.entity.enumeration.Role;
import com.airport.entity.enumeration.Status;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Assertions;


public class UserEntityTest {
    private User user;

    @BeforeEach
    public void setUp() {
        user = new User();
        user.setFirstName("John");
        user.setLastName("Doe");
        user.setAge(30);
        user.setGender("male");
        user.setContactNumber("1234567890");
        user.setEmailId("john.doe@example.com");
        user.setVendorId("vendor123");
        user.setPassword("password");
        user.setRole(Role.ROLE_ADMIN);
        user.setStatus(Status.APPROVED);
    }

    @Test
    public void testUserDtoFields() {
        Assertions.assertEquals("John", user.getFirstName());
        Assertions.assertEquals("Doe", user.getLastName());
        Assertions.assertEquals(30, user.getAge());
        Assertions.assertEquals("male", user.getGender());
        Assertions.assertEquals("1234567890", user.getContactNumber());
        Assertions.assertEquals("john.doe@example.com", user.getEmailId());
        Assertions.assertEquals("vendor123", user.getVendorId());
        Assertions.assertEquals("password", user.getPassword());
        Assertions.assertEquals(Role.ROLE_ADMIN, user.getRole());
        Assertions.assertEquals(Status.APPROVED, user.getStatus());
    }

    @Test
    public void testUserRoleAdmin() {
        user.setRole(Role.valueOf("ROLE_ADMIN"));
        Assertions.assertEquals(Role.ROLE_ADMIN.name(), user.getRole().name());
    }

    @Test
    public void testUserRoleUser() {
        user.setRole(Role.valueOf("ROLE_MANAGER"));
        Assertions.assertEquals(Role.ROLE_MANAGER.name(), user.getRole().name());
    }
}
