package com.airport.entity;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class HangerTest {

    private Hanger hanger;

    @BeforeEach
    public void setUp() {
        hanger = new Hanger();
        hanger.setId(1L);
        hanger.setHangerName("Hanger A");
        hanger.setLocation("Location A");
        hanger.setCapacity(10);
        hanger.setStatus("Available");
    }

    @Test
    public void testHangerEntity() {
        assertEquals(1L, hanger.getId());
        assertEquals("Hanger A", hanger.getHangerName());
        assertEquals("Location A", hanger.getLocation());
        assertEquals(10, hanger.getCapacity());
        assertEquals("Available", hanger.getStatus());
    }

    @Test
    public void testHangerNameNotNull() {
        hanger.setHangerName(null);
        assertNull(hanger.getHangerName());
    }

    @Test
    public void testLocationNotNull() {
        hanger.setLocation(null);
        assertNull(hanger.getLocation());
    }

    @Test
    public void testCapacityNotNull() {
        hanger.setCapacity(null);
        assertNull(hanger.getCapacity());
    }

    @Test
    public void testStatusNotNull() {
        hanger.setStatus(null);
        assertNull(hanger.getStatus());
    }
}
