package com.airport.repository;

import com.airport.entity.PlaneHanger;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PlaneHangerRepository extends JpaRepository<PlaneHanger, Long> {
//    List<PlaneHanger> findByHangarId(Long hangarId); // Find allocations by Hangar ID
//    List<PlaneHanger> findByPlaneId(Long planeId); // Find allocations by Plane ID
//    List<PlaneHanger> findByStatus(String status);

}