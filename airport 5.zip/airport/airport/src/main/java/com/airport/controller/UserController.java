package com.airport.controller;

import com.airport.entity.User;
import com.airport.entity.enumeration.Role;
import com.airport.entity.enumeration.Status;
import com.airport.payload.LoginDto;
import com.airport.payload.TokenDto;
import com.airport.payload.UserDto;
import com.airport.repository.UserRepository;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import com.airport.service.UserService;

@RestController
@RequestMapping("/api/v1/user")
public class UserController {

    private UserRepository userRepository;
    private UserService userService;


    public UserController(UserRepository userRepository, UserService userService) {
        this.userRepository = userRepository;
        this.userService = userService;
    }

    //http://localhost:8080/api/v1/user/register-admin
    @PostMapping("/register-admin")
    public ResponseEntity<?> registeUserAdmin(
            @Valid @RequestBody UserDto userDto,
            BindingResult result
    ) {
        if (userDto.getFirstName() == null || userDto.getLastName() == null || userDto.getPassword() == null) {
            return new ResponseEntity<>("please Update the highlighted manadatory fields", HttpStatus.BAD_REQUEST);
        }
        Optional<User> opEmailId = userRepository.findByEmailId(userDto.getEmailId());
        if (opEmailId.isPresent()) {
            return new ResponseEntity<>("Email already taken", HttpStatus.BAD_REQUEST);
        }
        Optional<User> opContactNumber = userRepository.findByContactNumber(userDto.getContactNumber());
        if (opContactNumber.isPresent()) {
            return new ResponseEntity<>("Contact number already taken", HttpStatus.BAD_REQUEST);
        }

        if (result.hasErrors()) {
            Map<String, String> errors = new HashMap<>();
            for (FieldError error : result.getFieldErrors()) {
                errors.put(error.getField(), error.getDefaultMessage());
            }
            return new ResponseEntity<>(errors, HttpStatus.BAD_REQUEST);
        }
        String encodedPassword = BCrypt.hashpw(userDto.getPassword(), BCrypt.gensalt(4));
        userDto.setPassword(encodedPassword);
//        userDto.setRole("ROLE_ADMIN");
        userDto.setRole(Role.valueOf("ROLE_ADMIN"));
        userDto.setStatus(Status.APPROVED);
        UserDto dto = userService.createUser(userDto);
        return new ResponseEntity<>("Your Details are submitted successfully", HttpStatus.CREATED);
    }

    //http://localhost:8080/api/v1/user/register-manager
    @PostMapping("/register-manager")
    public ResponseEntity<?> registeUserManager(
            @Valid @RequestBody UserDto dto,
            BindingResult result
    ) {
        if (dto.getFirstName() == null || dto.getLastName() == null || dto.getPassword() == null) {
            return new ResponseEntity<>("please Update the highlighted manadatory fields", HttpStatus.BAD_REQUEST);
        }
        Optional<User> opEmailId = userRepository.findByEmailId(dto.getEmailId());
        if (opEmailId.isPresent()) {
            return new ResponseEntity<>("Email already taken", HttpStatus.BAD_REQUEST);
        }
        Optional<User> opContactNumber = userRepository.findByContactNumber(dto.getContactNumber());
        if (opContactNumber.isPresent()) {
            return new ResponseEntity<>("Contact Number already taken", HttpStatus.BAD_REQUEST);
        }


        if (result.hasErrors()) {
            Map<String, String> errors = new HashMap<>();
            for (FieldError error : result.getFieldErrors()) {
                errors.put(error.getField(), error.getDefaultMessage());
            }
            return new ResponseEntity<>(errors, HttpStatus.BAD_REQUEST);
        }
        String encodedPassword = BCrypt.hashpw(dto.getPassword(), BCrypt.gensalt(4));
        dto.setPassword(encodedPassword);
//        dto.setRole("ROLE_MANAGER");
        dto.setRole(Role.valueOf("ROLE_MANAGER"));
        dto.setStatus(Status.UNAPPROVED);
        userService.createUser(dto);
        return new ResponseEntity<>("Your Details are submitted successfully. Awaiting approval from admin", HttpStatus.CREATED);
    }

    //http://localhost:8080/api/v1/user/login-admin
    @PostMapping("/login-admin")
    public ResponseEntity<?> loginAdminUser(
            @RequestBody LoginDto adminLoginDto
    ) {
        String token = userService.verifyLogin(adminLoginDto);
        if (token != null) {
            TokenDto tokenDto = new TokenDto();
            tokenDto.setToken(token);
            tokenDto.setType("JWT");
            return new ResponseEntity<>(tokenDto, HttpStatus.CREATED);
        } else {
            return new ResponseEntity<>("Invalid EmailId/Password", HttpStatus.FORBIDDEN);
        }
    }

    //http://localhost:8080/api/v1/user/login-manager
    @PostMapping("/login-manager")
    public ResponseEntity<?> loginManagerUser(
            @RequestBody LoginDto managerLoginDto
    ) {

        String token = userService.verifyLogin(managerLoginDto);
        if (token != null) {
            TokenDto tokenDto = new TokenDto();
            tokenDto.setToken(token);
            tokenDto.setType("JWT");
            return new ResponseEntity<>(tokenDto, HttpStatus.CREATED);
        } else {
            return new ResponseEntity<>("Invalid EmailId/Password", HttpStatus.FORBIDDEN);
        }
    }

    //http://localhost:8080/api/v1/user
    @GetMapping
    public ResponseEntity<List<UserDto>> getAllUsers(){
        List<UserDto> userDtos = userService.getAllUsers();
        return new ResponseEntity<>(userDtos, HttpStatus.OK);
    }

    //http://localhost:8080/api/v1/user/admin-approve/{managerEmailId}
    //Admin approves
    @PutMapping("/admin-approve/{managerEmailId}")
    public ResponseEntity<String> approveManager(
            @PathVariable String managerEmailId) {
        User user = userService.getUserByEmailId(managerEmailId);
        if (user == null) {
            return new ResponseEntity<>("User not found", HttpStatus.NOT_FOUND);
        }
        //admin approves manager
        UserDto userDto = userService.approveManagerUser(user.getEmailId());
        return new ResponseEntity<>("Manager approved successfully!!! \n manager details are as follows " + user, HttpStatus.OK);
    }

    //http://localhost:8080/api/v1/user/admin-reject/{managerEmailId}
    //Admin rejects a manager
    @PutMapping("/admin-reject/{managerEmailId}")
    public ResponseEntity<String> rejectManager(
            @PathVariable String managerEmailId) {
        User user = userService.getUserByEmailId(managerEmailId);
        if (user == null) {
            return new ResponseEntity<>("Manager not found", HttpStatus.NOT_FOUND);
        }
        //admin rejects manager
        userService.rejectManagerUser(user.getEmailId());
        return new ResponseEntity<>("Manager is rejected", HttpStatus.OK);
    }
}
