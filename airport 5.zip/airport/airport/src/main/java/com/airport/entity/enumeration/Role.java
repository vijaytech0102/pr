package com.airport.entity.enumeration;

public enum Role {
    ROLE_ADMIN, ROLE_MANAGER
}
