package com.airport.exception;

public class PilotNotFoundException extends RuntimeException{
    public PilotNotFoundException(String msg){
        super(msg);
    }
}
