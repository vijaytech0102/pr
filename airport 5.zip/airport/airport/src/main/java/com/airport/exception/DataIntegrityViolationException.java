package com.airport.exception;

public class DataIntegrityViolationException extends RuntimeException{
    DataIntegrityViolationException(String msg){
        super(msg);
    }
}
