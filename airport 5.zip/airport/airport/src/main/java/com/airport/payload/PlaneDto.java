package com.airport.payload;

import com.airport.entity.enumeration.PlaneStatus;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PlaneDto {
    private String planeName;
    private String model;
    private Integer capacity;
    private String status;
}
