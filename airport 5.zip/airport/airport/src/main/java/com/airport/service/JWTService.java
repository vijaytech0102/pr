package com.airport.service;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.DecodedJWT;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.UnsupportedEncodingException;
import java.util.Date;

@Service
public class JWTService{

    @Value("${jwt.algorithm.key}")
    private String algorithmKey;

    @Value("${jwt.issuer}")
    private String issuer;

    @Value("${jwt.expiry.duration}")
    private int expiryTime;

    private Algorithm algorithm;

    @PostConstruct
    public void postConstruct() throws UnsupportedEncodingException {
        algorithm = Algorithm.HMAC256(algorithmKey);
    }

    public String generateToken(String emailId){
        return JWT.create()
                .withClaim("username", emailId)
                .withIssuedAt(new Date())
                .withExpiresAt(new Date(System.currentTimeMillis()+expiryTime))
                .withIssuer(issuer)
                .sign(algorithm);
    }

//    public String generateTokenBasedOnManagerId(String managerId) {
//        return JWT.create()
//                .withClaim("username", managerId)
//                .withExpiresAt(new Date(System.currentTimeMillis()+expiryTime))
//                .withIssuer(issuer)
//                .sign(algorithm);
//    }

    public String getUserEmailFromTokenVal(String tokenVal){
        DecodedJWT decodeJwt = JWT.require(algorithm)
                .withIssuer(issuer)
                .build()
                .verify(tokenVal);
        return decodeJwt.getClaim("username").asString();
    }
}
