package com.airport.service.impl;

import com.airport.entity.Hanger;
import com.airport.entity.Plane;
import com.airport.entity.PlaneHanger;
import com.airport.payload.HangerDto;
import com.airport.payload.PlaneDto;
import com.airport.payload.PlaneHangerDto;
import com.airport.repository.HangerRepository;
import com.airport.repository.PlaneHangerRepository;
import com.airport.repository.PlaneRepository;
import com.airport.repository.UserRepository;
import com.airport.service.PlaneHangerService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class PlaneHangerServiceImpl implements PlaneHangerService {

    private UserRepository userRepository;
    private HangerRepository hangerRepository;
    private PlaneHangerRepository planeHangerRepository;
    private PlaneRepository planeRepository;
    private ObjectMapper objectMapper;

    public PlaneHangerServiceImpl(UserRepository userRepository, HangerRepository hangerRepository, PlaneHangerRepository planeHangerRepository, PlaneRepository planeRepository, ObjectMapper objectMapper) {
        this.userRepository = userRepository;
        this.hangerRepository = hangerRepository;
        this.planeHangerRepository = planeHangerRepository;
        this.planeRepository = planeRepository;
        this.objectMapper = objectMapper;
    }

    @Override
    public PlaneHangerDto allotPlaneToHangar(String planeName, String hangerName, PlaneHangerDto planeHangarDto){
        Plane plane = planeRepository.findByPlaneName(planeName).get();
        Hanger hanger = hangerRepository.findByHangerName(hangerName).get();
        PlaneHanger planeHanger = mapToEntity(planeHangarDto);
        planeHanger.setStatus("Available");
        planeHanger.setPlane(plane);
        planeHanger.setHanger(hanger);
        PlaneHanger savedPlaneHanger = planeHangerRepository.save(planeHanger);
        PlaneHangerDto dto = mapToDto(savedPlaneHanger);
        return dto;
    }
    private PlaneHanger mapToEntity(PlaneHangerDto planeHangarDto) {
        PlaneHanger planeHanger = objectMapper.convertValue(planeHangarDto, PlaneHanger.class);
        return planeHanger;
    }

    private PlaneHangerDto mapToDto(PlaneHanger planeHanger) {
        PlaneHangerDto planeHangerDto = objectMapper.convertValue(planeHanger, PlaneHangerDto.class);
        return planeHangerDto;
    }

    private PlaneDto mapToPlaneDto(Plane plane) {
        PlaneDto planeDto = objectMapper.convertValue(plane, PlaneDto.class);
        return planeDto;
    }

    public void deallocatePlaneFromHanger(Plane plane, Hanger hanger, PlaneHangerDto planeHangerDto) {
        PlaneHanger planeHanger = mapToEntity(planeHangerDto);
        planeHanger.setAllotmentDate(planeHangerDto.getAllotmentDate());
        planeHanger.setStatus(planeHangerDto.getStatus());
        planeHanger.setPlane(plane);
        planeHanger.setHanger(hanger);
        planeHangerRepository.save(planeHanger);
    }

    public List<PlaneDto> findAllPlanesDetails() {
        List<Plane> planes = planeRepository.findAll();
        List<PlaneDto> planeDtos = planes.stream().map(r -> mapToPlaneDto(r)).collect(Collectors.toList());
        return planeDtos;
    }

    public List<HangerDto> findAllHangersDetails() {
        List<Hanger> hangers = hangerRepository.findAll();
        List<HangerDto> hangerDtos = hangers.stream().map(h -> mapToHangerDto(h)).collect(Collectors.toList());
        return hangerDtos;
    }

    private HangerDto mapToHangerDto(Hanger hanger) {
        HangerDto hangerDto = objectMapper.convertValue(hanger, HangerDto.class);
        return hangerDto;
    }
}
