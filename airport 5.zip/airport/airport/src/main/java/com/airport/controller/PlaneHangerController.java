package com.airport.controller;

import com.airport.entity.Hanger;
import com.airport.entity.Plane;
import com.airport.payload.HangerDto;
import com.airport.payload.PlaneDto;
import com.airport.payload.PlaneHangerDto;
import com.airport.repository.HangerRepository;
import com.airport.repository.PlaneRepository;
import com.airport.service.HangerService;
import com.airport.service.PlaneHangerService;
import com.airport.service.PlaneService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/v1/plane-hanger")
public class PlaneHangerController {
    private PlaneHangerService planeHangerService;
    private HangerRepository hangerRepository;
    private PlaneRepository planeRepository;
    private PlaneService planeService;
    private HangerService hangerService;

    public PlaneHangerController(PlaneHangerService planeHangerService,
                                 HangerRepository hangerRepository,
                                 PlaneRepository planeRepository,
                                 PlaneService planeService,
                                 HangerService hangerService) {
        this.planeHangerService = planeHangerService;
        this.hangerRepository = hangerRepository;
        this.planeRepository = planeRepository;
        this.planeService = planeService;
        this.hangerService = hangerService;
    }


    @PostMapping("/allot-planeToHanger")
    @PreAuthorize("hasAuthority('ROLE_MANAGER')")
    public ResponseEntity<?> allotPlaneToHangar(
            @RequestBody PlaneHangerDto planeHangarDto,
            @RequestParam String planeName,
            @RequestParam String hangerName) {
        try {
            Optional<Hanger> opHangerName = hangerRepository.findByHangerName(hangerName);
            Optional<Plane> opPlaneName = planeRepository.findByPlaneName(planeName);
            if (opHangerName.isEmpty() || opPlaneName.isEmpty()) {
                return new ResponseEntity<>("Hanger or Plane not found.", HttpStatus.NOT_FOUND);
            }
            Plane plane = opPlaneName.get();
            Hanger hanger = opHangerName.get();
            // Check if the plane is INACTIVE or hangar capacity is greater than 0
            if (!"INACTIVE".equals(plane.getStatus()) || hanger.getCapacity() <= 0) {
                return new ResponseEntity<>("Plane cannot be allocated. Either" +
                        " the plane is not active or the hangar is full.", HttpStatus.BAD_REQUEST);
            }
            // Decrease the hangar capacity by 1
            hanger.setCapacity(hanger.getCapacity() - 1);
            hangerRepository.save(hanger);
            plane.setStatus("INACTIVE");
            planeRepository.save(plane);
            PlaneHangerDto dto = planeHangerService.allotPlaneToHangar(planeName, hangerName,
                    planeHangarDto);
            return new ResponseEntity<>("Plane Allocated to Hanger successfully",
                    HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>("Error allocating plane to hangar.",
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PreAuthorize("hasAuthority('ROLE_MANAGER')")
    @GetMapping("/manager-viewPlanes")
    public ResponseEntity<List<PlaneDto>> getAllPlanesInfo(){
        List<PlaneDto> planeDtos = planeHangerService.findAllPlanesDetails();
        return new ResponseEntity<>(planeDtos, HttpStatus.OK);
    }

    @PreAuthorize("hasAuthority('ROLE_MANAGER')")
    @GetMapping("/admin-view-hangers")
    public ResponseEntity<List<HangerDto>> getAllHangersInfo() {
        List<HangerDto> hangarDtos = planeHangerService.findAllHangersDetails();
        return new ResponseEntity<>(hangarDtos, HttpStatus.OK);
    }

    @PreAuthorize("hasAuthority('ROLE_MANAGER')")
    @PutMapping("/deallocate")
    public ResponseEntity<String> updatePlaneHangarStatus(
            @RequestParam String planeName,
            @RequestBody PlaneHangerDto planeHangerDto,
            @RequestParam String hangerName
            ) {
        try{
            Optional<Plane> opPlaneName = planeRepository.findByPlaneName(planeName);
            Optional<Hanger> opHangerName = hangerRepository.findByHangerName(hangerName);
            if(opHangerName.isEmpty()|| opPlaneName.isEmpty()){
                return new ResponseEntity<>("Plane or Hanger is not Found", HttpStatus.BAD_REQUEST);
            }
            Hanger hanger = opHangerName.get();
            Plane plane = opPlaneName.get();
            //Increase the hanger capacity by 1
            hanger.setCapacity(hanger.getCapacity() + 1);
            hangerRepository.save(hanger);
            plane.setStatus("ACTIVE");
            planeRepository.save(plane);
            planeHangerService.deallocatePlaneFromHanger(plane, hanger, planeHangerDto);
            return new ResponseEntity<>("PlaneHanger Status details has been updated..",HttpStatus.OK);
        }catch (Exception e){
            return new ResponseEntity<>("Error deallocating plane from hanger", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
