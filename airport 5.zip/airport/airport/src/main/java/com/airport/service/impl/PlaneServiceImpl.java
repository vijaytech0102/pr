package com.airport.service.impl;

import com.airport.entity.Plane;
import com.airport.exception.ResourceNotFoundException;
import com.airport.payload.PlaneDto;
import com.airport.repository.PlaneRepository;
import com.airport.repository.UserRepository;
import com.airport.service.PlaneService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class PlaneServiceImpl implements PlaneService {

    private PlaneRepository planeRepository;
    private UserRepository userRepository;
    private ObjectMapper objectMapper;

    public PlaneServiceImpl(PlaneRepository planeRepository, UserRepository userRepository, ObjectMapper objectMapper) {
        this.planeRepository = planeRepository;
        this.userRepository = userRepository;
        this.objectMapper = objectMapper;
    }

    @Override
    public PlaneDto createAddPlane(PlaneDto planeDto) {
        Plane plane = mapToEntity(planeDto);
        plane.setStatus("INACTIVE");
        planeRepository.save(plane);
        PlaneDto planeDto1 = mapToDto(plane);
        return planeDto1;
    }

    private Plane mapToEntity(PlaneDto planeDto) {
        Plane plane = objectMapper.convertValue(planeDto, Plane.class);
        return plane;
    }
    @Override
    public List<PlaneDto> findAllPlanesDetails() {
        List<Plane> planes = planeRepository.findAll();
        List<PlaneDto> dtos = planes.stream().map(r -> mapToDto(r)).collect(Collectors.toList());
        return dtos;
    }

    public PlaneDto mapToDto(Plane plane){
        PlaneDto planeDto = objectMapper.convertValue(plane, PlaneDto.class);
        return planeDto;
    }

    @Override
    public PlaneDto findPlaneDetailsById(Long planeId) {
        Plane plane = planeRepository.findById(planeId).orElseThrow(()-> new ResourceNotFoundException("Plane Details Not Found"));
        return mapToDto(plane);
    }

    @Override
    public Plane updatePlane(String planeName, Plane planeDetails) {
        Plane updatedPlane = planeRepository.findByPlaneName(planeName).get();
        updatedPlane.setPlaneName(planeDetails.getPlaneName());
        updatedPlane.setModel(planeDetails.getModel());
        updatedPlane.setCapacity(planeDetails.getCapacity());
        updatedPlane.setStatus(planeDetails.getStatus());
        return planeRepository.save(updatedPlane);
    }

    @Override
    public void deletePlane(String planeName) {
        Plane plane = planeRepository.findByPlaneName(planeName).get();
        planeRepository.deleteById(plane.getId());
    }
}
