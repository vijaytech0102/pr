package com.airport.service;

import com.airport.entity.User;
import com.airport.payload.LoginDto;
import com.airport.payload.UserDto;

import java.util.List;

public interface UserService {

    UserDto createUser(UserDto userDto);

    String verifyLogin(LoginDto adminLoginDto);

    List<UserDto> getAllUsers();

    User getUserByEmailId(String managerEmailId);

    UserDto approveManagerUser(String emailId);

    void rejectManagerUser(String emailId);
}

