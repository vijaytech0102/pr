package com.airport.exception;

public class MethodArgumentNotValidException extends RuntimeException {
    MethodArgumentNotValidException(String msg){
        super(msg);
    }
}
