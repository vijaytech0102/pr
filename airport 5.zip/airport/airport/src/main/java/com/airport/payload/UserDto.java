package com.airport.payload;

import com.airport.entity.enumeration.Role;
import com.airport.entity.enumeration.Status;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserDto {
    private String firstName;
    private String lastName;
    private Integer age;
    private String gender;
    private String contactNumber;
    private String emailId;
    private String vendorId;
    private String password;
    //    private String role;
    private Role role;
    private Status status;
}
