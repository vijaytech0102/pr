package com.airport.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "hanger")
@Entity
public class Hanger {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @NotNull(message = "hangerName is required")
    @Column(nullable = false)
    private String hangerName; // Name of the Hangar


    @NotNull(message = "location is required")
    @Column(name = "location", nullable = false)
    private String location;

    @NotNull(message = "Capacity is required")
    @Column(name = "capacity", nullable = false)
    private Integer capacity;

    @NotNull(message = "status is required")
    @Column(name = "status", nullable = false)
    private String status; //"Available" or "Allotted"

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user; // Admin who added the hangar

//    @JsonIgnore
//    @OneToMany(mappedBy = "hanger")
//    private List<PlaneHanger> planeHangers;

}