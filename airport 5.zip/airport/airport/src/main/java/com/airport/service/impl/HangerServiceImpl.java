package com.airport.service.impl;

import com.airport.entity.Hanger;
import com.airport.entity.User;
import com.airport.exception.ResourceNotFoundException;
import com.airport.payload.HangerDto;
import com.airport.repository.HangerRepository;
import com.airport.repository.UserRepository;
import com.airport.service.HangerService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class HangerServiceImpl implements HangerService {

    private HangerRepository hangerRepository;
    private UserRepository userRepository;
    private ObjectMapper objectMapper;

    public HangerServiceImpl(HangerRepository hangerRepository, UserRepository userRepository, ObjectMapper objectMapper) {
        this.hangerRepository = hangerRepository;
        this.userRepository = userRepository;
        this.objectMapper = objectMapper;
    }
    @Override
    public HangerDto addHanger(Hanger hanger) {
        Hanger savedHanger = hangerRepository.save(hanger);
        HangerDto hangerDto = mapToDto(savedHanger);
        return hangerDto;
    }

    private Hanger mapToEntity(HangerDto hangerDto) {
        Hanger hanger = objectMapper.convertValue(hangerDto, Hanger.class);
        return hanger;
    }

    @Override
    public Hanger updateHanger(String hangerName, Hanger hangerDetails, String emailId) {
        Hanger hanger = hangerRepository.findByHangerName(hangerName).orElseThrow(() -> new ResourceNotFoundException("Hanger not found"));
        User user = userRepository.findByEmailId(emailId).get();
        // Decrease the hangar capacity by 1
        hanger.setHangerName(hangerDetails.getHangerName());
        hanger.setLocation(hangerDetails.getLocation());
        hanger.setCapacity(hangerDetails.getCapacity() - 1);
        // If the hangar capacity reaches 0, change the status to Alloted
        if (hanger.getCapacity() <= 0) {
            hanger.setStatus("Alloted");
        }
         //Decrease the capacity by 1 only if the current capacity is greater than 0
//        if (hanger.getCapacity() > 0) {
//            hanger.setCapacity(hanger.getCapacity() - 1);
//        } else {
//            throw new IllegalStateException("Hanger capacity cannot be less than 0");
//        }
        hanger.setStatus("Allotted");
        hanger.setUser(user);
        Hanger updatedHanger = hangerRepository.save(hanger);
        return updatedHanger;
    }

    @Override
    public HangerDto getHangerById(Long hangerId) {
        Hanger hanger = hangerRepository.findById(hangerId).orElseThrow(
                () -> new ResourceNotFoundException("Hanger details not found")
        );
        HangerDto hangerDto = mapToDto(hanger);
        return hangerDto;
    }

    private HangerDto mapToDto(Hanger hanger) {
        HangerDto hangerDto = objectMapper.convertValue(hanger, HangerDto.class);
        return hangerDto;
    }

    @Override
    public List<HangerDto> getAllHangers() {
        List<Hanger> hangers = hangerRepository.findAll();
        List<HangerDto> hangerDtos = hangers.stream().map(h -> mapToDto(h)).collect(Collectors.toList());
        return hangerDtos;
    }


    @Override
    public void deleteHanger(Long id) {
        hangerRepository.deleteById(id);
    }
}
