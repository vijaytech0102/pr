package com.airport.service.impl;

import com.airport.entity.Pilot;
import com.airport.entity.Plane;
import com.airport.exception.ResourceNotFoundException;
import com.airport.payload.PilotDto;
import com.airport.repository.PilotRepository;
import com.airport.repository.PlaneRepository;
import com.airport.service.PilotService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class PilotServiceImpl implements PilotService {

    private PilotRepository pilotRepository;
    private PlaneRepository planeRepository;
    private ObjectMapper objectMapper;

    public PilotServiceImpl(PilotRepository pilotRepository, PlaneRepository planeRepository, ObjectMapper objectMapper) {
        this.pilotRepository = pilotRepository;
        this.planeRepository = planeRepository;
        this.objectMapper = objectMapper;
    }

    @Override
    public PilotDto savePilotDetails(PilotDto pilotDto) {
        Pilot pilot = mapToEntity(pilotDto);
        pilotRepository.save(pilot);
        PilotDto dto = mapToDto(pilot);
        return dto;
    }
    private Pilot mapToEntity(PilotDto pilotDto) {
        Pilot pilot = objectMapper.convertValue(pilotDto, Pilot.class);
        return pilot;
    }

    private PilotDto mapToDto(Pilot pilot) {
        PilotDto pilotDto = objectMapper.convertValue(pilot, PilotDto.class);
        return pilotDto;
    }

    @Override
    public List<PilotDto> getAllPilots() {
        List<Pilot> pilots = pilotRepository.findAll();
        List<PilotDto> pilotDtos = pilots.stream().map(this::mapToDto).collect(Collectors.toList());
        return pilotDtos;
    }

    @Override
    public Pilot getPilotById(Long id) {
        Pilot pilot = pilotRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Pilot not found with id: " + id));
        return pilot;
    }

    @Override
    public Pilot updatePilot(String licenseNumber, Pilot pilo, String planeName) {
        Pilot updatedPilot = pilotRepository.findByLicenseNumber(licenseNumber).get();
        Plane plane = planeRepository.findByPlaneName(planeName).get();
//        PilotDto dto = mapToDto(updatedPilot);
        updatedPilot.setFirstName(pilo.getFirstName());
        updatedPilot.setLastName(pilo.getLastName());
        updatedPilot.setLicenseNumber(pilo.getLicenseNumber());
        updatedPilot.setExperience(pilo.getExperience());
        updatedPilot.setContactNumber(pilo.getContactNumber());
        updatedPilot.setPlane(plane);
//        Pilot changedPilot = mapToEntity(dto);
        Pilot savedPilot = pilotRepository.save(updatedPilot);
        return savedPilot;
    }

    @Override
    public void deletePilot(String contactNumber) {
        Pilot pilot = pilotRepository.findByContactNumber(contactNumber)
                .orElseThrow(() -> new ResourceNotFoundException("Pilot not found with contact number " + contactNumber));
        pilotRepository.delete(pilot);
    }
}
