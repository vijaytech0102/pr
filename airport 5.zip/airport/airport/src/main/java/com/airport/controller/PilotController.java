package com.airport.controller;

import com.airport.entity.Pilot;
import com.airport.exception.PilotNotFoundException;
import com.airport.payload.PilotDto;
import com.airport.repository.PilotRepository;
import com.airport.repository.PlaneRepository;
import com.airport.repository.UserRepository;
import com.airport.service.PilotService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/v1/pilots")
public class PilotController {

    private PilotService pilotService;

    private UserRepository userRepository;
    private PlaneRepository planeRepository;
    private PilotRepository pilotRepository;

    public PilotController(PilotService pilotService, UserRepository userRepository, PlaneRepository planeRepository, PilotRepository pilotRepository) {
        this.pilotService = pilotService;
        this.userRepository = userRepository;
        this.planeRepository = planeRepository;
        this.pilotRepository = pilotRepository;
    }

//    http://localhost:8080/api/v1/pilots/admin/add-pilot
    @PostMapping("/admin/add-pilot")
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<?> addPilot(
            @Valid @RequestBody PilotDto pilotDto,
            BindingResult result
    ) {
        try {
            Optional<Pilot> opContactNumber = pilotRepository.findByContactNumber(pilotDto.getContactNumber());
            if(opContactNumber.isPresent()){
                return new ResponseEntity<>("contact number already taken", HttpStatus.BAD_REQUEST);
            }
            Optional<Pilot> opLicenseNumber = pilotRepository.findByLicenseNumber(pilotDto.getLicenseNumber());
            if(opLicenseNumber.isPresent()){
                return new ResponseEntity<>("License Number already exists!!!", HttpStatus.BAD_REQUEST);
            }
            if (result.hasErrors()) {
                Map<String, String> errors = new HashMap<>();
                for (FieldError error : result.getFieldErrors()) {
                    errors.put(error.getField(), error.getDefaultMessage());
                }
                return new ResponseEntity<>(errors, HttpStatus.BAD_REQUEST);
            }
            PilotDto dto = pilotService.savePilotDetails(pilotDto);
            return new ResponseEntity<>("Pilot details added successfully!!!", HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>("Failed to add pilot details: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

//    http://localhost:8080/api/v1/pilots/view
    @GetMapping("/view")
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<List<PilotDto>> getAllPilots() {
        List<PilotDto> pilotDtos = pilotService.getAllPilots();
        return new ResponseEntity<>(pilotDtos, HttpStatus.OK);
    }

//    http://localhost:8080/api/v1/pilots/view/{id}
    @GetMapping("/view/{id}")
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<Pilot> getPilotById(
            @PathVariable Long id
    ) {
        Pilot pilot = pilotService.getPilotById(id);
        return new ResponseEntity<>(pilot, HttpStatus.OK);
    }

//    http://localhost:8080/api/v1/pilots/update/{id}
    @PutMapping("/update/{licenseNumber}/{planeName}")
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<?> updatePilotDetails(
            @RequestBody Pilot pilo,
            @PathVariable String licenseNumber,
            @PathVariable String planeName
    ) {
        Pilot updatedPilot = pilotService.updatePilot(licenseNumber, pilo, planeName);
        return new ResponseEntity<>("Pilot details updated successfully!!!!", HttpStatus.OK);
    }

//    http://localhost:8080/api/v1/pilots/delete/{pilotId}
    @DeleteMapping("/delete/{contactNumber}")
    public ResponseEntity<String> deletePilot(
            @PathVariable String contactNumber){
        try{
//            boolean isDeleted = pilotService.deletePilot(contactNumber);
            pilotService.deletePilot(contactNumber);
//            if(isDeleted){
//                return new ResponseEntity<>("Pilot deleted successfully.", HttpStatus.OK);
//            }
//            else{
//                return new ResponseEntity<>("Pilot not found", HttpStatus.NOT_FOUND);
//            }
        }catch (PilotNotFoundException e){
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>("Deleted", HttpStatus.OK);
    }
}
