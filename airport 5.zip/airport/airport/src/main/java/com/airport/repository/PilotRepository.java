package com.airport.repository;

import com.airport.entity.Pilot;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface PilotRepository extends JpaRepository<Pilot, Long> {
    Optional<Pilot> findByLicenseNumber(String licenseNumber);
    Optional<Pilot> findByContactNumber(String contactNumber);
}