package com.airport.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "plane_hanger")
public class PlaneHanger {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "plane_hanger_id", nullable = false)
    private Long planeHangarId;

    @NotNull(message = "Date cannot be null")
    private LocalDate allotmentDate;

    @NotNull(message = "status is required")
    @Column(name="status", nullable = false)
    private String status;

    @ManyToOne
    @JoinColumn(name = "plane_id")
    private Plane plane;

    @ManyToOne
    @JoinColumn(name = "hanger_id")
    private Hanger hanger;

}