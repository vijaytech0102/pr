package com.airport.entity.enumeration;

public enum PlaneStatus {
    ACTIVE, INACTIVE
}
