package com.airport.exception;

public class UserDetailsNotFoundException extends Throwable {
    public UserDetailsNotFoundException(String msg){
        super(msg);
    }
}
