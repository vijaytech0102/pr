package com.airport.entity;

import com.airport.entity.enumeration.Role;
import com.airport.entity.enumeration.Status;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;

import java.util.List;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Data
@Table(name = "user")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @NotNull
    @Column(name = "first_name", nullable = false)
    private String firstName;

    @NotNull
    @Column(name = "last_name", nullable = false)
    private String lastName;

    @Min(value = 18, message = "Age should not be less than 18")
    @Max(value = 100, message = "Age should not be greater than 100")
    @Column(name = "age", nullable = false)
    private Integer age;

    @Pattern(regexp = "^(male|female|other)$", message = "Gender must be 'male', 'female', or 'other'")
    @Column(name = "gender", nullable = false)
    private String gender;

    @Pattern(regexp = "^\\d{10}$", message = "Contact number must be a 10-digit number")
    @Column(name = "contact_number", nullable = false, unique = true)
    private String contactNumber;

    @Email
    @Column(name = "email_id", nullable = false, unique = true)
    private String emailId;

    @Size(min = 2, max = 30, message = "Id must have at least 2 characters")
    @Column(name = "vendor_id", nullable = false, unique = true)
    private String vendorId;

    @Column(name = "password", length = 500, nullable = false)
    private String password;

//    @Column(name = "role", length = 500, nullable = false)
//    private String role;

    @Enumerated(EnumType.STRING)
    @Column(name = "role", length = 500, nullable = false)
    private Role role;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Status status;

}