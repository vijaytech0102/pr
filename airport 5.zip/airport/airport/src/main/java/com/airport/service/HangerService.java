package com.airport.service;

import com.airport.entity.Hanger;
import com.airport.payload.HangerDto;

import java.util.List;

public interface HangerService {
    HangerDto addHanger(Hanger hanger);

    Hanger updateHanger(String hangerName, Hanger hanger, String emailId);

    HangerDto getHangerById(Long hangerId);

    List<HangerDto> getAllHangers();

    void deleteHanger(Long id);
}
