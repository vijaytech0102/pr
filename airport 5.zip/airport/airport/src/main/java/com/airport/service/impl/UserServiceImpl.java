package com.airport.service.impl;

import com.airport.entity.User;
import com.airport.entity.enumeration.Status;
import com.airport.exception.ResourceNotFoundException;
import com.airport.exception.UserDetailsNotFoundException;
import com.airport.payload.LoginDto;
import com.airport.payload.UserDto;
import com.airport.repository.UserRepository;
import com.airport.service.JWTService;
import com.airport.service.UserService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class UserServiceImpl implements UserService {


    private UserRepository userRepository;
    private JWTService jwtService;
    private ObjectMapper objectMapper;

    public UserServiceImpl(UserRepository userRepository, JWTService jwtService, ObjectMapper objectMapper) {
        this.userRepository = userRepository;
        this.jwtService = jwtService;
        this.objectMapper = objectMapper;
    }


    @Override
    public UserDto createUser(UserDto userDto) {
        User user = mapToEntity(userDto);
        User savedUser = userRepository.save(user);
        UserDto dto = mapToDto(savedUser);
        return dto;
    }

    private User mapToEntity(UserDto userDto) {
        User user = objectMapper.convertValue(userDto, User.class);
        return user;
    }

    private UserDto mapToDto(User savedUser) {
        UserDto dto = objectMapper.convertValue(savedUser, UserDto.class);
        return dto;
    }

    @Override
    public List<UserDto> getAllUsers() {
        List<User> users = userRepository.findAll();
        List<UserDto> userDtos = users.stream().map(r -> mapToDto(r)).collect(Collectors.toList());
        return userDtos;
    }


    public User updateUser(Long id, User user) throws UserDetailsNotFoundException {
        Optional<User> opAdminId = userRepository.findById(id);
        if (opAdminId.isPresent()) {
            User updatedUser = opAdminId.get();
            updatedUser.setFirstName(user.getFirstName());
            updatedUser.setLastName(user.getLastName());
            updatedUser.setAge(user.getAge());
            updatedUser.setGender(user.getGender());
            updatedUser.setContactNumber(user.getContactNumber());
            updatedUser.setEmailId(user.getEmailId());
            updatedUser.setVendorId(user.getVendorId());
            updatedUser.setPassword(user.getPassword());
            updatedUser.setRole(user.getRole());
            updatedUser.setStatus(user.getStatus());
            User savedUser = userRepository.save(updatedUser);
            return savedUser;

        }
        else{
            throw new UserDetailsNotFoundException("User Details Are Not Found With this Id:"+id);
        }
    }


//    public void delete(Long id) {
//        userRepository.deleteById(id);
//    }

    @Override
    public User getUserByEmailId(String managerEmailId) {
        User user = userRepository.findByEmailId(managerEmailId).orElseThrow(
                ()->new ResourceNotFoundException("Resource Not Found")
        );
        return user;
    }

    @Override
    public String verifyLogin(LoginDto dto) {
        Optional<User> opEmailId = userRepository.findByEmailId(dto.getEmailId());
        if (opEmailId.isPresent()) {
            User user = opEmailId.get();
            if (user.getStatus() == Status.APPROVED) {
                if (BCrypt.checkpw(dto.getPassword(), user.getPassword())) {
                    String token = jwtService.generateToken(dto.getEmailId());
                    return token;
                } else {
                    return "Error: Incorrect password.";
                }
            } else {
                return "Error: User is not approved.";
            }
        }
        return "Error: User not found.";
    }
    @Override
    public UserDto approveManagerUser(String emailId) {
        User user = userRepository.findByEmailId(emailId).orElseThrow(
                ()->new ResourceNotFoundException("User not found")
        );
        user.setStatus(Status.APPROVED);
        User updatedUser = userRepository.save(user);
        UserDto userDto = mapToDto(updatedUser);
        return userDto;
    }


    @Override
    public void rejectManagerUser(String emailId) {
        User user = userRepository.findByEmailId(emailId).orElseThrow(
                ()->new ResourceNotFoundException("User not found")
        );
        user.setStatus(Status.UNAPPROVED);
        userRepository.save(user);
        return;
    }
}
