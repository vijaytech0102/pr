package com.airport.exception;

import com.airport.payload.ErrorDto;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

import java.util.Date;


@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<ErrorDto> resourceNotFound(
            ResourceNotFoundException r,
            WebRequest request
    ){
        ErrorDto error = new ErrorDto(r.getMessage(), new Date(), request.getDescription(true));
        return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(UserDetailsNotFoundException.class)
    public ResponseEntity<String> adminDetailsNotFound(
            UserDetailsNotFoundException e
    ){
        return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(UserAlreadyExistsException.class)
    public ResponseEntity<String> adminExistsException(
            UserAlreadyExistsException a
    ){
        return new ResponseEntity<>(a.getMessage(), HttpStatus.CONFLICT);
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<String> methodArgumentNotValid(
            MethodArgumentNotValidException m
    ){
        return new ResponseEntity<>(m.getMessage(), HttpStatus.BAD_REQUEST);
    }

    //------------------------------------//
//    @ExceptionHandler(DataIntegrityViolationException.class)
//    public ResponseEntity<String> handleDataIntegrityViolationException(
//            DataIntegrityViolationException ex,
//            WebRequest request
//    ){
//        return new ResponseEntity<>(ex.getRootCause().getMessage(), new Date(), request.getDescription(false), HttpStatus.CONFLICT);
//    }
//
//    @ExceptionHandler(AminUserAlreadyExistsException.class)
//    public ResponseEntity<String> handleAdminUserAlreadyExistsException(AminUserAlreadyExistsException ex) {
//        return new ResponseEntity<>(ex.getMessage(), HttpStatus.CONFLICT);
//    }

//    @ExceptionHandler(MethodArgumentNotValidException.class)
//    public ResponseEntity<Map<String, String>> handleValidationExceptions(MethodArgumentNotValidException ex) {
//        Map<String, String> errors = new HashMap<>();
//        List<ObjectError> allErrors = ex.getBindingResult().getAllErrors();
//        for (ObjectError error : allErrors) {
//            String fieldName = ((FieldError) error).getField();
//            String errorMessage = error.getDefaultMessage();
//            errors.put(fieldName, errorMessage);
//        }
//        return new ResponseEntity<>(errors, HttpStatus.BAD_REQUEST);
//    }

    @ExceptionHandler(PilotNotFoundException.class)
    public ResponseEntity<String> pilotNotFoundException(
            PilotNotFoundException p
    ){
        return new ResponseEntity<>(p.getMessage(), HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<String> handleGlobalExceptions
    (Exception e){
        return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
