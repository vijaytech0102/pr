package com.airport.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.access.intercept.AuthorizationFilter;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;


@Configuration
//@EnableWebSecurity
//@EnableMethodSecurity (prePostEnabled = true, securedEnabled = true)
public class SecurityConfig {

    private JWTFilter jwtFilter;

    public SecurityConfig(JWTFilter jwtFilter) {
        this.jwtFilter = jwtFilter;
    }


    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity httpSecurity) throws Exception {
        httpSecurity.csrf().disable().cors().disable();
        httpSecurity.addFilterBefore(jwtFilter, AuthorizationFilter.class);
        httpSecurity.authorizeHttpRequests()
                .requestMatchers("/v3/api-docs/**", "/swagger-ui/**", "/swagger-ui.html",
                        "/api/v1/user/register-admin","/api/v1/user/register-manager",
                        "/api/v1/user/login-admin", "/api/v1/user/login-manager").permitAll()
                .requestMatchers("/api/v1/user","/api/v1/user/admin-approve/{managerEmailId}",
                        "/api/v1/user/admin-reject/{managerEmailId}","/api/v1/plane/admin/add-plane",
                "/api/v1/plane/admin-viewPlanes","/api/v1/plane/view-plane-byId/{planeId}",
                        "/api/v1/plane/admin-update-planeInfo","/api/v1/plane",
                        "/api/v1/pilots/admin/add-pilot","/api/v1/pilots/view",
                        "/api/v1/pilots/view/{id}","/api/v1/pilots/update/{id}",
                        "/api/v1/pilots/delete/{contactNumber}","/api/v1/hanger/addHanger",
                        "/api/v1/hanger/admin-update/{hangerName}","/api/v1/hanger/admin-view-specificHanger/{hangerId}",
                        "/api/v1/hanger/admin-view-hangers","/api/v1/hanger").hasRole("ADMIN")
                .requestMatchers("/api/v1/plane-hanger/allot-planeToHanger","/api/v1/plane-hanger/manager-viewPlanes",
                        "/api/v1/plane-hanger/deallocate","/api/v1/plane-hanger/admin-view-hangers").hasRole("MANAGER")
                .anyRequest().authenticated();
//        httpSecurity.authorizeHttpRequests().anyRequest().permitAll();
        return httpSecurity.build();
    }
}