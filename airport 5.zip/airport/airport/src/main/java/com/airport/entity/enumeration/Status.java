package com.airport.entity.enumeration;

public enum Status {
    APPROVED, UNAPPROVED
}
