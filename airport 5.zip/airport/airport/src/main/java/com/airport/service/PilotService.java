package com.airport.service;

import com.airport.entity.Pilot;
import com.airport.payload.PilotDto;

import java.util.List;

public interface PilotService {
    PilotDto savePilotDetails(PilotDto pilotDto);

    List<PilotDto> getAllPilots();

    Pilot getPilotById(Long id);

    Pilot updatePilot(String licenseNumber, Pilot pilo, String planeName);

    void deletePilot(String contactNumber);
}
