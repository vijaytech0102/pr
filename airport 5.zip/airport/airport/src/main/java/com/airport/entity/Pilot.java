package com.airport.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "pilot")
public class Pilot {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;


    @NotNull
    @Column(name = "first_name", nullable = false)
    private String firstName;

    //    @NotEmpty(message = "Last Name is mandatory")
    @NotNull
//    @Size(min = 2, max = 30, message = "Last Name must be between 2 and 30 characters")
    @Column(name = "last_name", nullable = false)
    private String lastName;

    @NotNull
    @Column(name = "license_number", nullable = false)
    private String licenseNumber;

    @NotNull
    @Column(name = "experience", nullable = false)
    private Integer experience;

    @NotNull
    @Pattern(regexp = "^\\d{10}$", message = "Contact number must be a 10-digit number")
    @Column(name = "contact_number",nullable = false, unique = true)
    private String contactNumber;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "plane_id")
    private Plane plane;

}