package com.airport.controller;

import com.airport.entity.Plane;
import com.airport.payload.PlaneDto;
import com.airport.repository.PlaneRepository;
import com.airport.repository.UserRepository;
import com.airport.service.PlaneService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/v1/plane")
public class PlaneController {
    private PlaneService planeService;
    private UserRepository userRepository;
    private PlaneRepository planeRepository;

    public PlaneController(PlaneService planeService, UserRepository userRepository,
                           PlaneRepository planeRepository) {
        this.planeService = planeService;
        this.userRepository = userRepository;
        this.planeRepository = planeRepository;
    }


    //  /api/v1/plane/admin/add-plane
    @PostMapping("/admin/add-plane")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public ResponseEntity<?> addPlane(@Valid @RequestBody PlaneDto planeDto,
                                           BindingResult result){
        Optional<Plane> opPlaneName = planeRepository.findByPlaneName(planeDto.getPlaneName());
        if(opPlaneName.isPresent()){
            return new ResponseEntity<>("PlaneName already taken",HttpStatus.BAD_REQUEST);
        }
        if (result.hasErrors()) {
            Map<String, String> errors = new HashMap<>();
            for (FieldError error : result.getFieldErrors()) {
                errors.put(error.getField(), error.getDefaultMessage());
            }
            return new ResponseEntity<>(errors, HttpStatus.BAD_REQUEST);
        }
        PlaneDto dto = planeService.createAddPlane(planeDto);
        return new ResponseEntity<>("plane details added successfully!!!!", HttpStatus.CREATED);
    }


    // /api/v1/plane/admin-viewPlanes
    @GetMapping("/admin-viewPlanes")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public ResponseEntity<List<PlaneDto>> getAllPlanesInfo(){
        List<PlaneDto> planeDtos = planeService.findAllPlanesDetails();
        return new ResponseEntity<>(planeDtos, HttpStatus.OK);
    }

    // /api/v1/plane/view-plane-byId/{planeId}
    @GetMapping("/view-plane-byId/{planeId}")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public ResponseEntity<PlaneDto> viewPlaneInfoById
            (@PathVariable Long planeId){
        PlaneDto planeDto = planeService.findPlaneDetailsById(planeId);
        return new ResponseEntity<>(planeDto, HttpStatus.OK);
    }

    //    /api/v1/plane/admin-update/{planeName}
    @PutMapping("/admin-update-planeInfo")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public ResponseEntity<String>  updatePlaneInfo(
            @RequestBody Plane planeDetails,
            @RequestParam String planeName
    ){
        Plane updatePlane = planeService.updatePlane(planeName, planeDetails);
        return new ResponseEntity<>("Plane details are updated successfully!!!", HttpStatus.OK);
    }

    @DeleteMapping()
    public ResponseEntity<String> deletePlane(
            @RequestParam String planeName
    ){
        planeService.deletePlane(planeName);
        return new ResponseEntity<>("Plane details are Deleted successfully!!!",
                HttpStatus.OK);

    }
}
