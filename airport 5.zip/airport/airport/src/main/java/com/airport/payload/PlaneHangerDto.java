package com.airport.payload;

import com.airport.entity.Hanger;
import com.airport.entity.Plane;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PlaneHangerDto {
    private Long planeHangarId;
    private LocalDate allotmentDate;
    private String status;
    private Plane plane;
    private Hanger hanger;
}
