package com.airport.service;

import com.airport.entity.Plane;
import com.airport.payload.PlaneDto;

import java.util.List;

public interface PlaneService {
    PlaneDto createAddPlane(PlaneDto planeDto);

    List<PlaneDto> findAllPlanesDetails();

    PlaneDto findPlaneDetailsById(Long planeId);

    Plane updatePlane(String planeName, Plane planeDetails);

    void deletePlane(String planeName);
}
