package com.airport.controller;

import com.airport.entity.Hanger;
import com.airport.entity.User;
import com.airport.payload.HangerDto;
import com.airport.repository.HangerRepository;
import com.airport.repository.UserRepository;
import com.airport.service.HangerService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/v1/hanger")
public class HangerController {
    private HangerService hangerService;
    private HangerRepository hangerRepository;
    private UserRepository userRepository;

    public HangerController(HangerService hangerService,
                            HangerRepository hangerRepository,
                            UserRepository userRepository) {
        this.hangerService = hangerService;
        this.hangerRepository = hangerRepository;
        this.userRepository = userRepository;
    }

    // Admin-only: Add Hangar (redirect to add Plane)
    @PostMapping("/addHanger")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")// Only Admin can add Hangars
    public ResponseEntity<?> addHangar(
            @Valid @RequestBody Hanger hanger,
            @RequestParam String emailId,
            BindingResult result) {
        try {
            Optional<Hanger> opHangerName = hangerRepository.findByHangerName(hanger.getHangerName());
            if(opHangerName.isPresent()){
                return new ResponseEntity<>("Hanger Name already taken", HttpStatus.BAD_REQUEST);
            }
            if (result.hasErrors()) {
                Map<String, String> errors = new HashMap<>();
                for (FieldError error : result.getFieldErrors()) {
                    errors.put(error.getField(), error.getDefaultMessage());
                }
                return new ResponseEntity<>(errors, HttpStatus.BAD_REQUEST);
            }
            User user = userRepository.findByEmailId(emailId).get();
            hanger.setStatus("Available");
            hanger.setUser(user);
            HangerDto hangerDto = hangerService.addHanger(hanger);
            return new ResponseEntity<>(hangerDto, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("Error adding hangar.", HttpStatus.BAD_REQUEST);
        }
    }

    // Admin-only: Update Hangar details
    @PutMapping("/admin-update/{hangerName}")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')") // Only Admin can update Hangars
    public ResponseEntity<String> updateHangar(
            @RequestBody Hanger hanger,
            @PathVariable String hangerName,
            @RequestParam String emailId) {
        try {
            Hanger updatedHanger = hangerService.updateHanger(hangerName, hanger, emailId);
            return new ResponseEntity<>("Hangar updated successfully.", HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("Error updating hangar.", HttpStatus.BAD_REQUEST);
        }
    }

    // Admin-only: Get Hangar by ID
    @GetMapping("/admin-view-specificHanger/{hangerId}")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")// Only Admin can view hangars
    public ResponseEntity<HangerDto> getHangerById(
            @PathVariable Long hangerId) {
        HangerDto hangerDto = hangerService.getHangerById(hangerId);
        return new ResponseEntity<>(hangerDto, HttpStatus.OK);
    }

    // Admin-only: View all Hangars
    @GetMapping("/admin-view-hangers")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')") // Only Admin can view all hangars
    public ResponseEntity<List<HangerDto>> getAllHangersByAdmin() {
        List<HangerDto> hangarDtos = hangerService.getAllHangers();
        return new ResponseEntity<>(hangarDtos, HttpStatus.OK);
    }

    @DeleteMapping
    public ResponseEntity<String> deleteHanger(@RequestParam Long id){
        hangerService.deleteHanger(id);
        return new ResponseEntity<>("deleted", HttpStatus.OK);
    }

}
