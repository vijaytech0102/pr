package com.airport.service;

import com.airport.entity.Hanger;
import com.airport.entity.Plane;
import com.airport.payload.HangerDto;
import com.airport.payload.PlaneDto;
import com.airport.payload.PlaneHangerDto;

import java.util.List;

public interface PlaneHangerService {
    PlaneHangerDto allotPlaneToHangar(String planeName, String hangerName, PlaneHangerDto planeHangarDto);

    List<PlaneDto> findAllPlanesDetails();

    List<HangerDto> findAllHangersDetails();

    void deallocatePlaneFromHanger(Plane plane, Hanger hanger, PlaneHangerDto planeHangerDto);
}
