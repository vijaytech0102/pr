import { Component } from '@angular/core';

@Component({
  selector: 'app-pilots',
  standalone: false,
  templateUrl: './pilots.component.html',
  styleUrl: './pilots.component.css'
})
export class PilotsComponent {

}
