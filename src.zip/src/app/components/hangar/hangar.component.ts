import { Component } from '@angular/core';

@Component({
  selector: 'app-hangar',
  standalone: false,
  templateUrl: './hangar.component.html',
  styleUrl: './hangar.component.css'
})
export class HangarComponent {

}
