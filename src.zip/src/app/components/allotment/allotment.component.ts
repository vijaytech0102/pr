import { Component } from '@angular/core';

@Component({
  selector: 'app-allotment',
  standalone: false,
  templateUrl: './allotment.component.html',
  styleUrl: './allotment.component.css'
})
export class AllotmentComponent {

}
