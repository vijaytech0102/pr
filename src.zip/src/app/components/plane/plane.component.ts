import { Component } from '@angular/core';

@Component({
  selector: 'app-plane',
  standalone: false,
  templateUrl: './plane.component.html',
  styleUrl: './plane.component.css'
})
export class PlaneComponent {

}
