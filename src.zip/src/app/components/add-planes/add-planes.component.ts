import { Component } from '@angular/core';

@Component({
  selector: 'app-add-planes',
  standalone: false,
  templateUrl: './add-planes.component.html',
  styleUrl: './add-planes.component.css'
})
export class AddPlanesComponent {

}
