import { Allotment } from './allotment.model';

describe('Allotment', () => {
  it('should create an instance', () => {
    expect(new Allotment()).toBeTruthy();
  });
});
