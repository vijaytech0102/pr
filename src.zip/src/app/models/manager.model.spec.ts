import { Manager } from './manager.model';

describe('Manager', () => {
  it('should create an instance', () => {
    expect(new Manager()).toBeTruthy();
  });
});
