import { Plane } from './plane.model';

describe('Plane', () => {
  it('should create an instance', () => {
    expect(new Plane()).toBeTruthy();
  });
});
