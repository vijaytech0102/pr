import { Pilot } from './pilot.model';

describe('Pilot', () => {
  it('should create an instance', () => {
    expect(new Pilot()).toBeTruthy();
  });
});
