import { Hanger } from './hanger.model';

describe('Hanger', () => {
  it('should create an instance', () => {
    expect(new Hanger()).toBeTruthy();
  });
});
