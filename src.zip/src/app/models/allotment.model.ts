export class Allotment {
}
